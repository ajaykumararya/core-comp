<?php
$keyId = 'rzp_live_VemjlywIgaj1E6';

$keySecret = 'TOLmIIbnr5uMMlFnwc72z9vB';

$displayCurrency = 'INR';
?>