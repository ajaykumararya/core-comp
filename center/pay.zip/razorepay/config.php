<?php
require_once '../../admin/includes/config.php';
require_once 'key.php';


?>